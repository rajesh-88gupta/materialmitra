package com.materialmitra.MaterialMitra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaterialMitraApplicationTests {

	@Test
	void contextLoads() {
	}

}
